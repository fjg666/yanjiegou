<?php
namespace app\api\model;
use think\Model;
use think\Db;
class Bigshop extends Model
{
}