<?php
namespace app\api\model;
use think\Model;
use think\Db;
class Information extends Model
{

}