<?php
namespace app\api\model;
use think\Model;
use think\Db;
class Recvaddr extends Model
{
}