<?php
namespace app\common\model;
use think\Model;
class UsersCard extends Model
{

//    protected $pk = 'ensh_article';
}