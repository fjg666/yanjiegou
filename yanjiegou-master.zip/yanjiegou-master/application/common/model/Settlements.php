<?php
namespace app\common\model;
use think\Model;
class Settlements extends Model
{

}