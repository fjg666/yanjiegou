<?php
namespace app\common\model;
use think\Model;
class Order extends Model
{
    //protected $autoWriteTimestamp = true;
    // protected $createTime = "createtime";
    // protected $updateTime = "updatetime";
}

