<?php
namespace app\common\model;
use think\Model;
class ShopPostage extends Model
{
    //protected $autoWriteTimestamp = true;
    // protected $createTime = "createtime";
    // protected $updateTime = "updatetime";
}

