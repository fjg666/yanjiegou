<?php
namespace app\common\model;
use think\Model;
class ShopFundNow extends Model
{
    //protected $autoWriteTimestamp = true;
    // protected $createTime = "createtime";
    // protected $updateTime = "updatetime";
}

