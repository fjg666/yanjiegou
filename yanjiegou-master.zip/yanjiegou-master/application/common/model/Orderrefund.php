<?php
namespace app\common\model;
use think\Model;
use think\Db;
class Orderrefund extends Model
{
	
		protected $resultSetType = 'collection';
	
}