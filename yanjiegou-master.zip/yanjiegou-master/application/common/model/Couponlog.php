<?php
namespace app\common\model;
use think\Model;
class Couponlog extends Model
{

}