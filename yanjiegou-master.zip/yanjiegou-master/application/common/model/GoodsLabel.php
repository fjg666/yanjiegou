<?php
namespace app\common\model;
use think\Model;
class GoodsLabel extends Model
{

//    protected $pk = 'ensh_article';
}