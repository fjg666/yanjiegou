<?php
namespace app\admin\model;
use think\Model;
use think\Db;
class Coupon extends Model
{

}