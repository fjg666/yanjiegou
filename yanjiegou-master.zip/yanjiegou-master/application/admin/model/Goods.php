<?php
namespace app\admin\model;
use think\Model;
class Goods extends Model
{
    protected $autoWriteTimestamp = true;
    protected $createTime = "createtime";
    protected $updateTime = "updatetime";

}

