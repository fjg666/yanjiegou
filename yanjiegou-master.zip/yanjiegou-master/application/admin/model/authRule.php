<?php
namespace app\admin\model;
use think\Model;
class authRule extends Model
{

}