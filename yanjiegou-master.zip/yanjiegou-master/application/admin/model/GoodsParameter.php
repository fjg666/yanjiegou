<?php
namespace app\admin\model;
use think\Model;
use think\Db;
use ensh\Tree;
class GoodsParameter extends Model{
    
}