<?php
namespace app\bigshop\model;
use think\Model;
class BigshopAuthRule extends Model
{

}