<?php
namespace app\common\model;
use think\Model;
class Coupon extends Model
{

}