<?php
namespace app\common\model;
use think\Model;
class UsersCardGet extends Model
{

}