<?php

return [
    'appid'=>"wx4d7fa47003d86b9e",
    'appsecret'=>"3721c1001b3163f514fdcbe6fa748864"
]

?>