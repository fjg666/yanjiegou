<?php
/**
+----------------------------------------------------------------------
 * 微信配置
+----------------------------------------------------------------------
 */
return [
    'appkey'=> 'LTAINuEkVgXnz2fQ',
    'secretKey'=> '7Us7TyhRVMCEIb7afTVVjAuPwMrRM7',
    //短信签名
    'signName'=>'沿街购',
    'signName2'=>'源领网络科技',
    'templateCode'=>'SMS_166778801',
    'templateCode2'=>'SMS_177257361',
];