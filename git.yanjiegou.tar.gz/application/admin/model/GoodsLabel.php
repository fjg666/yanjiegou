<?php
namespace app\admin\model;
use think\Model;
use think\Db;
class GoodsLabel extends Model
{

//    protected $pk = 'ensh_article';
}