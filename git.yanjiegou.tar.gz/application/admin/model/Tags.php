<?php
namespace app\admin\model;

use think\Model;

class Tags extends Model
{
    protected $name = 'tags';

}