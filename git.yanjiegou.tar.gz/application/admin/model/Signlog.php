<?php
namespace app\admin\model;
use think\Model;
use think\Db;
class Signlog extends Model
{

} 

