<?php
return [
	//模板输出替换
	'view_replace_str'  =>  [
		'__PUBLIC__'=>'/static/upload',
	    'JS'=>'/static/admin/js',
	    'CSS'=>'/static/admin/css',
	    'IMG'=>'/static/admin/images',
	    'FONTS'=>'/static/admin/fonts',
	    'LIB'=>'/static/admin/lib',
    ],
];
