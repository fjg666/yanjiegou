<?php
namespace app\shop\model;
use think\Model;
class ShopAuthRule extends Model
{

}